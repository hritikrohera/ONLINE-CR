-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.0.13-rc-nt


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema recruit
--

CREATE DATABASE IF NOT EXISTS recruit;
USE recruit;

--
-- Definition of table `com`
--

DROP TABLE IF EXISTS `com`;
CREATE TABLE `com` (
  `CName` varchar(255) default NULL,
  `CAddress` varchar(255) default NULL,
  `CPost` varchar(255) default NULL,
  `CCriteria` varchar(255) default NULL,
  `CUsername` varchar(255) NOT NULL default '',
  `CEmail` varchar(255) default NULL,
  `CContact` varchar(255) default NULL,
  `CCutoff` varchar(255) default NULL,
  PRIMARY KEY  (`CUsername`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `com`
--

/*!40000 ALTER TABLE `com` DISABLE KEYS */;
INSERT INTO `com` (`CName`,`CAddress`,`CPost`,`CCriteria`,`CUsername`,`CEmail`,`CContact`,`CCutoff`) VALUES 
 ('IT Networking','arera colony bhopal','arera colony','BE','itnet','itnet@gmail.com','9907331446','60'),
 ('Persistance','Nagpur','Developer','M.Tech.','Persistance','persistance@gmail.com','9871234567','70'),
 ('tcs','bhopal','programmer','be','tcs','tcs@gmail.com','9087654321','60'),
 ('wipro','Banglore','S/w Engineer','Mtech,tt','wipro','wipro@yahoo.com','0487564783','60');
/*!40000 ALTER TABLE `com` ENABLE KEYS */;


--
-- Definition of table `copy_of_exam`
--

DROP TABLE IF EXISTS `copy_of_exam`;
CREATE TABLE `copy_of_exam` (
  `ExamID` varchar(255) NOT NULL default '',
  `ExamName` varchar(255) default NULL,
  `Cutoff` varchar(255) default NULL,
  PRIMARY KEY  (`ExamID`),
  KEY `ExamID` (`ExamID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `copy_of_exam`
--

/*!40000 ALTER TABLE `copy_of_exam` DISABLE KEYS */;
/*!40000 ALTER TABLE `copy_of_exam` ENABLE KEYS */;


--
-- Definition of table `details`
--

DROP TABLE IF EXISTS `details`;
CREATE TABLE `details` (
  `Username` varchar(255) default NULL,
  `Name` varchar(255) default NULL,
  `Gender` varchar(255) default NULL,
  `DateOfBirth` varchar(255) default NULL,
  `CollegeName` varchar(255) default NULL,
  `CollegePhone` varchar(255) default NULL,
  `CollegeEmail` varchar(255) default NULL,
  `Branch` varchar(255) default NULL,
  `Mark` varchar(255) default NULL,
  `Degree` varchar(255) default NULL,
  `Email_id` varchar(255) default NULL,
  `Telephone` varchar(255) default NULL,
  `Address` varchar(255) default NULL,
  `State` varchar(255) default NULL,
  `Pincode` varchar(255) default NULL,
  `Category` varchar(255) default NULL,
  KEY `Email_id` (`Email_id`),
  KEY `Pincode` (`Pincode`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `details`
--

/*!40000 ALTER TABLE `details` DISABLE KEYS */;
INSERT INTO `details` (`Username`,`Name`,`Gender`,`DateOfBirth`,`CollegeName`,`CollegePhone`,`CollegeEmail`,`Branch`,`Mark`,`Degree`,`Email_id`,`Telephone`,`Address`,`State`,`Pincode`,`Category`) VALUES 
 ('asha','ashaq','Female','08/08/09','UIT','057684955','uit@ymail.com','Comp Science               ','89','MCA','asha@ymail.com','748774','TVM','KL','695646','Experienced'),
 ('hhh','ajith','Female','56','Mohandas College','343434','cvbc@.com','Comp Technology            ','89','BTech','d@.com','233411','Kollam','MN','722222','Fresher'),
 ('hhhtr','jajkljss','Female','56','fdsgdsfh','456578679','sddfdeg@.','Comp Technology            ','89','BTech','kk@.','67656767','fhgfjhgj','MN','75','Fresher'),
 ('hhhtrrds','jajkljss','Female','56','fdsgdsfh','456578679','sddfdeg@.','Comp Technology            ','89','BTech','kk@.','67656767','fhgfjhgj','MN','667','Fresher'),
 ('bhushan','asas','Female','6-7-98','gfgf','9876543210','vbbvbv@gmail.com','Applied Electro            ','56','BTech','bhushandabre@gmail.com','9087654321','bhopal','MP','234567','Fresher'),
 ('anil','anil kushwah','Male','16/07/86','sati','475364','sati@gmail.com','Information Technology     ','60','BTech','akushwah190@gmail.com','9907331446','dabra(gwalior)','MP','475110','Fresher'),
 ('piyush','piyush Mayank Gupta','Male','12-12-1908','sati','9087654321','bvbvbvbv@gmail.com','Information Technology     ','80','BTech','piyush@gmail.com','9876543210','bhopal','MP','462016','Fresher');
/*!40000 ALTER TABLE `details` ENABLE KEYS */;


--
-- Definition of table `exam`
--

DROP TABLE IF EXISTS `exam`;
CREATE TABLE `exam` (
  `JobID` varchar(255) default NULL,
  `Post` varchar(255) default NULL,
  `ExamID` varchar(255) default NULL,
  `ExamName` varchar(255) default NULL,
  `Cutoff` varchar(255) default NULL,
  KEY `ExamID` (`ExamID`),
  KEY `JobID` (`JobID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exam`
--

/*!40000 ALTER TABLE `exam` DISABLE KEYS */;
INSERT INTO `exam` (`JobID`,`Post`,`ExamID`,`ExamName`,`Cutoff`) VALUES 
 ('100','Programmer','1','Java','60'),
 ('101','center manager','3','web based','70'),
 ('103','staff','1','java','90'),
 ('100','Programmer','3','web based','78'),
 ('1000','staff','1','java','80');
/*!40000 ALTER TABLE `exam` ENABLE KEYS */;


--
-- Definition of table `experienced`
--

DROP TABLE IF EXISTS `experienced`;
CREATE TABLE `experienced` (
  `Username` varchar(255) NOT NULL default '',
  `ExpYears` varchar(255) default NULL,
  `Company` varchar(255) default NULL,
  `Designation` varchar(255) default NULL,
  `Salary` varchar(255) default NULL,
  `ComAddress` varchar(255) default NULL,
  PRIMARY KEY  (`Username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `experienced`
--

/*!40000 ALTER TABLE `experienced` DISABLE KEYS */;
INSERT INTO `experienced` (`Username`,`ExpYears`,`Company`,`Designation`,`Salary`,`ComAddress`) VALUES 
 ('asha','22','HCL','pgmr','75000','chennai');
/*!40000 ALTER TABLE `experienced` ENABLE KEYS */;


--
-- Definition of table `jobdetails`
--

DROP TABLE IF EXISTS `jobdetails`;
CREATE TABLE `jobdetails` (
  `JobId` varchar(255) NOT NULL default '',
  `Post` varchar(255) default NULL,
  `Criteria` varchar(255) default NULL,
  `NoOfVacancies` varchar(255) default NULL,
  `Salary` varchar(255) default NULL,
  `LastDate` varchar(255) default NULL,
  PRIMARY KEY  (`JobId`),
  KEY `JobId` (`JobId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jobdetails`
--

/*!40000 ALTER TABLE `jobdetails` DISABLE KEYS */;
INSERT INTO `jobdetails` (`JobId`,`Post`,`Criteria`,`NoOfVacancies`,`Salary`,`LastDate`) VALUES 
 ('100','Programmer','MTech','2','100000','13/5/84'),
 ('1000','staff','bsc','7','456789','9-9-09'),
 ('101','center manager','MBA','4','34567','8-10-2009'),
 ('103','staff','BSC','7','4500','6-7-09'),
 ('56','manager','MBA','10','46567','567457'),
 ('null','null','null','null','null','null');
/*!40000 ALTER TABLE `jobdetails` ENABLE KEYS */;


--
-- Definition of table `login`
--

DROP TABLE IF EXISTS `login`;
CREATE TABLE `login` (
  `Username` varchar(255) NOT NULL default '',
  `Password` varchar(255) default NULL,
  `Status` varchar(255) default NULL,
  PRIMARY KEY  (`Username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

/*!40000 ALTER TABLE `login` DISABLE KEYS */;
INSERT INTO `login` (`Username`,`Password`,`Status`) VALUES 
 ('admin','adminadmin','a'),
 ('ak','14490','s'),
 ('anil','9907331446','s'),
 ('asha','12345','s'),
 ('bhushan','1234','s'),
 ('hhh','12345','s'),
 ('itnet','9907331446','c'),
 ('Persistance','Persistance','c'),
 ('piyush','12345678','s'),
 ('tcs','12345678','c'),
 ('wipro','wiprowipro','c');
/*!40000 ALTER TABLE `login` ENABLE KEYS */;


--
-- Definition of table `question`
--

DROP TABLE IF EXISTS `question`;
CREATE TABLE `question` (
  `JobID` varchar(255) default NULL,
  `ExamID` varchar(255) default NULL,
  `QuestionNo` int(11) default NULL,
  `Question` varchar(255) default NULL,
  `Option1` varchar(255) default NULL,
  `Option2` varchar(255) default NULL,
  `Option3` varchar(255) default NULL,
  `Option4` varchar(255) default NULL,
  `Answer` varchar(255) default NULL,
  KEY `ExamId` (`ExamID`),
  KEY `JobID` (`JobID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `question`
--

/*!40000 ALTER TABLE `question` DISABLE KEYS */;
INSERT INTO `question` (`JobID`,`ExamID`,`QuestionNo`,`Question`,`Option1`,`Option2`,`Option3`,`Option4`,`Answer`) VALUES 
 ('100','1',4,'void main()\r\n{\r\nfloat j;\r\nj=1000*1000;\r\nprintf(â??%fâ??,jâ??);\r\n}\r\n','Overflow','1000000','Error',' None','None'),
 ('100','1',6,'if j=8 and k=j++ what will be the value of j and k?','8 and 9','9 and 8','9 and 9',' 8 and 8','8 and 9'),
 ('100','1',7,'Run time errors are known as ________.','Compile error','static error','Exception',' Error','Exception'),
 ('100','1',8,'__________ is a used for finding number of elements in an array.','object.length','object.length()','length()',' length','length()'),
 ('100','1',9,'Packages are included in a java program using','import','include','insert',' join','import'),
 ('100','1',1,'c supports?','polymorphism','class','structure','oops','structure'),
 ('100','1',2,'asdff','a','b','c','d','b'),
 ('100','1',10,'1+1=?','10','11','2','all of the above.','all of the above.'),
 ('100','1',10,'jnsjnsjdsjnsds','a','b','c','d','a'),
 ('100','1',5,'java support?','static','class','exception','all','all'),
 ('100','1',3,'java suports?','class','polymorphism','inheritance','all','all');
/*!40000 ALTER TABLE `question` ENABLE KEYS */;


--
-- Definition of table `result`
--

DROP TABLE IF EXISTS `result`;
CREATE TABLE `result` (
  `studentID` varchar(255) default NULL,
  `examID` varchar(255) default NULL,
  `jobID` varchar(255) default NULL,
  `mark` int(11) default NULL,
  KEY `ExamID` (`examID`),
  KEY `JobID` (`jobID`),
  KEY `StudentID` (`studentID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `result`
--

/*!40000 ALTER TABLE `result` DISABLE KEYS */;
INSERT INTO `result` (`studentID`,`examID`,`jobID`,`mark`) VALUES 
 ('asha','1','100',3),
 ('asha','2','100',3),
 ('asha','1','100',6),
 ('asha','1','100',4),
 ('asha','3','101',0),
 ('bhushan','1','100',0),
 ('bhushan','1','100',1),
 ('bhushan','1','100',0),
 ('bhushan','1','100',1);
/*!40000 ALTER TABLE `result` ENABLE KEYS */;


--
-- Definition of table `temp`
--

DROP TABLE IF EXISTS `temp`;
CREATE TABLE `temp` (
  `qno` int(10) unsigned NOT NULL auto_increment,
  `no` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`qno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `temp`
--

/*!40000 ALTER TABLE `temp` DISABLE KEYS */;
INSERT INTO `temp` (`qno`,`no`) VALUES 
 (1,0),
 (2,0),
 (3,0),
 (4,0),
 (5,0),
 (6,0),
 (7,0),
 (8,0),
 (9,0),
 (10,0);
/*!40000 ALTER TABLE `temp` ENABLE KEYS */;


--
-- Definition of table `temp_data`
--

DROP TABLE IF EXISTS `temp_data`;
CREATE TABLE `temp_data` (
  `StudID` varchar(255) default NULL,
  `QstNo` int(11) default NULL,
  `Qst` varchar(255) default NULL,
  `Ch1` varchar(255) default NULL,
  `Ch2` varchar(255) default NULL,
  `Ch3` varchar(255) default NULL,
  `Ch4` varchar(255) default NULL,
  `Ans` varchar(255) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `temp_data`
--

/*!40000 ALTER TABLE `temp_data` DISABLE KEYS */;
INSERT INTO `temp_data` (`StudID`,`QstNo`,`Qst`,`Ch1`,`Ch2`,`Ch3`,`Ch4`,`Ans`) VALUES 
 ('piyush',1,'if j=8 and k=j++ what will be the value of j and k?','8 and 9','9 and 8','9 and 9',' 8 and 8','8 and 9'),
 ('piyush',3,'asdff','a','b','c','d','b'),
 ('piyush',4,'1+1=?','10','11','2','all of the above.','all of the above.'),
 ('piyush',7,'__________ is a used for finding number of elements in an array.','object.length','object.length()','length()',' length','length()'),
 ('piyush',9,'Run time errors are known as ________.','Compile error','static error','Exception',' Error','Exception');
/*!40000 ALTER TABLE `temp_data` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
